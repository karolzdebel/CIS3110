CIS3110 Assignment 2

Author: Karol Zdebel (0892519)

Program Functionality: FCFS is complete and working, Round robin produces almost correct output for verbose
mode and detail mode but due to small error the deafult results are off.

References: