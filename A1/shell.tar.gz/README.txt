CIS3110 Assignment 1

Author: Karol Zdebel (0892519)

References:

Functionality:
-Section 1(Complete)
-Section 2(Complete)
-Secion 3(Incomplete)
	-Only stored path variable but no bash functionality is associated with it, if you look at my shell.c file you will find functions associate with it. This includes a data structure that 
	stores all the directories. The default path unix variable
	is read into this data structure using exec.
	-No other functionality was implemented for this section.
